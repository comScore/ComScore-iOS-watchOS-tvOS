//
// Copyright 2016 comScore, Inc. All right reserved.
//

typedef enum {
    SCORSessionStateInactive,
    SCORSessionStateApplication,
    SCORSessionStateUser,
    SCORSessionStateActiveUser
} SCORSessionState;